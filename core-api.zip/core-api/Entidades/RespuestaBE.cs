﻿
namespace CoreApi.Entidades
{
    public class RespuestaBE
    {
        public string title { get; set; }
        public string code { get; set; }
        public int status { get; set; }
        public string message { get; set; }
        public string messageDetail { get; set; }
        public bool retornoBool { get; set; }

       
    }
}
